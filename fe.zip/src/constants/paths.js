export const PATH = {
  HOME: '/',
  DASHBOARD: '/dashboard',
  NEW_USER: 'new',
  EDIT_USER: ':login/edit',
  LOGIN: '/login',
  REGISTER: '/register',
  FORGOT_PASSWORD: '/forgot-password',
  ERROR_403: '/forbidden',
  ANY: '*',
}
