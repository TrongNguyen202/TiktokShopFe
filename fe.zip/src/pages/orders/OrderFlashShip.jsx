const OrderFlashShip = () => {
    return (
        <div className="p-10">OrderFlashShip</div>
    );
}
 
export default OrderFlashShip;