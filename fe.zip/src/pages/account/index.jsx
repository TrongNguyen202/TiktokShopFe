import PageTitle from "../../components/common/PageTitle";

const Account = () => {
    return (
        <div className="p-10">
            <PageTitle title='My account'/>
        </div>
    )
}
 
export default Account;